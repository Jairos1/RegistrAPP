export interface Docente {
    id: Number;
    nombre: String;
    correo: String;
    contraseña: String;
    jornada: String;
}
export interface Asignatura {
    seccion: Number;
    asignatura: String;
    profesor: String;
    hora: Number;
    dia: String;
}
export interface Asignaturas {
    asignatura: String;
    profesor: String;
    hora: Number;
    dia: String;
}