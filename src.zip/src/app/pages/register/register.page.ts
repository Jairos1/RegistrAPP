import { Component, OnInit } from '@angular/core';
import { MenuController } from '@ionic/angular';
import { AlertController } from '@ionic/angular';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

export class Usuario {
  nombre: string = '';
  edad: number | null = null;
  fechanacimiento: string = '';
  numerotelefono: number | null = null;
  carrera: string = '';
  jornada: string = '';
  correo: string = '';
  contraseña: string = '';
}

@Component({
  selector: 'app-register',
  templateUrl: './register.page.html',
  styleUrls: ['./register.page.scss'],
})
export class RegisterPage implements OnInit {
  usuarioForm: FormGroup;

  constructor(
    private menuController: MenuController,
    private alertController: AlertController,
    private formBuilder: FormBuilder
  ) {
    this.usuarioForm = this.formBuilder.group({
      nombre: ['', Validators.required, Validators.minLength(5)],
      edad: ['', Validators.required],
      fechanacimiento: ['', Validators.required],
      numerotelefono: ['', Validators.required, Validators.minLength(9)],
      carrera: ['', Validators.required, Validators.minLength(8)],
      jornada: ['', Validators.required],
      correo: ['', [Validators.required, Validators.email, Validators.minLength(8)]],
      contraseña: ['', [Validators.required, Validators.minLength(8)]],
    });
  }

  ngOnInit() { }

  MostrarMenu() {
    this.menuController.open('first');
  }

  async Enviar() {
    if (this.usuarioForm.valid) {
      const formData = this.usuarioForm.value;
      const usuarioData = new Usuario();
      Object.assign(usuarioData, formData);

      const alert = await this.alertController.create({
        header: 'Gracias!' + ' ' + usuarioData.nombre,
        message: 'Sus datos han sido enviados!',
        buttons: ['OK'],
      });

      await alert.present();
      
      this.usuarioForm.reset();
    }
  }
}