import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Asignatura } from '../pages/interfaces/interfaces';
import { Asignaturas } from '../pages/interfaces/interfaces';


@Injectable({
  providedIn: 'root'
})
export class ApiCrudService {

  constructor(private httpclient:HttpClient) { }

  ListarAsignatura(): Observable<Asignaturas[]> {
    return this.httpclient.get<Asignaturas[]>(`${environment.apiUrl}/asignatura`);
  }
}
