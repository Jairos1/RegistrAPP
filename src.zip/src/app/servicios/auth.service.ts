import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { Docente } from '../pages/interfaces/interfaces';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private httpclient: HttpClient) { }

  GetAllUsers(){
    return this.httpclient.get<Docente>(`${environment.apiUrl}/usuarios`);
  }

  GetUserById(codigo: any): Observable<Docente> {
    return this.httpclient.get<Docente>(`${environment.apiUrl}/usuarios/?correo=${codigo}`);
  }

  IsLoggedIn() {
    return sessionStorage.getItem('correo')!=null;
  }

  //GetUserrole() {
  //  return sessionStorage.getItem('userrole')!=null?sessionStorage.getItem('userrole')?.toString();
  //}

}
