import { Component, OnInit } from '@angular/core';
import { MenuController } from '@ionic/angular';
import { AlertController } from '@ionic/angular';

@Component({
  selector: 'app-register',
  templateUrl: './register.page.html',
  styleUrls: ['./register.page.scss'],
})
export class RegisterPage implements OnInit {

  usuario = {
    nombre: '',
    apellidos: '',
    direccion: '',
    rut: '',
    email: '',
    edad: '',
    numerotelefono: '',
    fechanacimiento: '',
    password: ''
  }

  constructor(private menuController: MenuController,
    private alertController: AlertController) { }

  ngOnInit() {
  }

  MostrarMenu() {
    this.menuController.open('first');
  }

  async Enviar() {
    const alert = await this.alertController.create({
      header: 'Gracias!' + ' ' + this.usuario.nombre,
      message: 'Sus datos han sido enviados!',
      buttons: ['OK'],
    });

    await alert.present();
    this.usuario.edad = '';
    this.usuario.nombre = '';
    this.usuario.apellidos = '';
    this.usuario.direccion = '';
    this.usuario.email = '';
    this.usuario.rut = '';
    this.usuario.password = '';
    this.usuario.numerotelefono = '';
  }

}
