import { Component, OnInit } from '@angular/core';
import { MenuController } from '@ionic/angular';
import { AuthService } from 'src/app/servicios/auth.service';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { ToastController } from '@ionic/angular';
import { FormBuilder, Validators, FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {

  userdata: any;

  usuario = {
    id: 0,
    nombre: "",
    edad: "",
    fechanacimiento: "",
    numerotelefono: "",
    carrera: "",
    jornada: "",
    correo: "",
    contraseña: "",
  }

  loginForm: FormGroup;

  constructor(private menuController: MenuController,
    private authservice: AuthService,
    private router: Router,
    private alertcontroller: AlertController,
    private toastcontroller: ToastController,
    private builder: FormBuilder) {
    this.loginForm = this.builder.group({
      'correo': new FormControl("", [Validators.required, Validators.minLength(10), Validators.maxLength(50)]),
      'contraseña': new FormControl("", [Validators.required, Validators.minLength(8)])
    })
  }

  ngOnInit() {
  }

  async showToast(title: string, message: string) {
    const toast = await this.toastcontroller.create({
      message: message,
      duration: 3000,
      position: 'bottom'
    });
    toast.present();
  }

  async Error() {
    const alerta = await this.alertcontroller.create({
      header: 'Error...',
      message: 'Revise bien su correo',
      buttons: ['Ok']
    })
    await alerta.present();
  }

  async NoExiste() {
    const alerta = await this.alertcontroller.create({
      header: 'Error...',
      message: 'No existe, debe registrarse en la pagina',
      buttons: ['Ok']
    })
    await alerta.present();
  }

  login() {
    if (this.loginForm.valid) {
      this.authservice.GetUserById(this.loginForm.value.correo).subscribe({
        next: (resp) => {
          this.userdata = resp;
          console.log("Datos del usuario recuperados:", this.userdata);
          if (this.userdata.length > 0) {
            this.usuario = {
              id: this.userdata[0].id,
              nombre: this.userdata[0].nombre,
              edad: this.userdata[0].edad,
              fechanacimiento: this.userdata[0].fechanacimiento,
              numerotelefono: this.userdata[0].numerotelefono,
              carrera: this.userdata[0].carrera,
              jornada: this.userdata[0].jornada,
              correo: this.userdata[0].correo,
              contraseña: this.userdata[0].contraseña
            };
  
            if (this.usuario.contraseña === this.loginForm.value.contraseña) {
              sessionStorage.setItem('correo', this.usuario.correo);
              sessionStorage.setItem('jornada', this.usuario.jornada);
              this.showToast('Sesión Iniciada', 'Bienvenido usuario:' + this.usuario.nombre);
              this.router.navigateByUrl("/inicio");
            } else {
              this.Error();
              console.log("Error: Contraseña incorrecta");
            }
          } else {
            this.NoExiste();
            console.log("Error: Usuario no existe");
          }
        },
        error: (error) => {
          console.error("Error en la solicitud HTTP:", error);
        }
      });
    }
  }

  MostrarMenu() {
    this.menuController.open('first');
  }
}