import { Component, OnInit } from '@angular/core';
import { IonInfiniteScroll, MenuController } from '@ionic/angular';
import { ApiCrudService } from 'src/app/servicios/api-crud.service';
import { LoadingController } from '@ionic/angular';
import { InfiniteScrollCustomEvent } from '@ionic/angular';


@Component({
  selector: 'app-asignatura',
  templateUrl: './asignatura.page.html',
  styleUrls: ['./asignatura.page.scss'],
})
export class AsignaturaPage  {

  asignaturas = []

  constructor(private menuController: MenuController,
              private asignaturasService : ApiCrudService,
              private loadingCtrl : LoadingController) { }

  ionViewWillEnter(){
  this.loadAsignatura();
  }
  
  MostrarMenu(){
    this.menuController.open('first');
  }

  async loadAsignatura(event?: InfiniteScrollCustomEvent){
  
    const loading = await this.loadingCtrl.create({
      message: "Cargando...",
      spinner: "bubbles"
    });
    await loading.present();

    this.asignaturasService.ListarAsignatura().subscribe(
      {
        next: resp=>{
          console.log(resp);
          loading.dismiss();
          let listString = JSON.stringify(resp)
          this.asignaturas = JSON.parse(listString)
          event?.target.complete();
          console.log(this.asignaturas);

        },
        error: err =>{
          console.log(err.error.message);
          loading.dismiss();
        }
      }
    )
  }


}
