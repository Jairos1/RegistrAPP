import { Component, OnInit } from '@angular/core';
import { MenuController } from '@ionic/angular';
import { AlertController } from '@ionic/angular';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import { of } from 'rxjs';

export class Usuarios {
  nombre: string = '';
  edad: number | null = null;
  fechanacimiento: string = '';
  numerotelefono: number | null = null;
  carrera: string = '';
  jornada: string = '';
  correo: string = '';
  contraseña: string = '';
}

@Component({
  selector: 'app-register',
  templateUrl: './register.page.html',
  styleUrls: ['./register.page.scss'],
})
export class RegisterPage implements OnInit {
  usuarioForm: FormGroup;

  constructor(
    private menuController: MenuController,
    private alertController: AlertController,
    private formBuilder: FormBuilder,
    private http: HttpClient 
  ) {
    this.usuarioForm = this.formBuilder.group({
      'nombre': new FormControl(" ", [Validators.required, Validators.minLength(5)]),
      'edad': new FormControl('', [Validators.required]),
      'fechanacimiento': new FormControl('', [Validators.required]),
      'numerotelefono': new FormControl('', [Validators.required, Validators.minLength(9)]),
      'carrera': new FormControl('', [Validators.required, Validators.minLength(8)]),
      'jornada': new FormControl('', [Validators.required]),
      'correo': new FormControl("", [Validators.required, Validators.minLength(10), Validators.maxLength(50)]),
      'contraseña': new FormControl("", [Validators.required, Validators.minLength(8)])
    });
  }

  ngOnInit() { }

  MostrarMenu() {
    this.menuController.open('first');
  }

  async Enviar() {
    if (this.usuarioForm.valid) {
      const formData = this.usuarioForm.value;
      const usuarioData = new Usuarios();
      Object.assign(usuarioData, formData);
  
      this.http.post('http://localhost:3300/usuarios', usuarioData)
        .pipe(
          catchError(error => {
            console.error('Error al guardar los datos:', error);
            return of(null);
          })
        )
        .subscribe({
          next: async (response) => {
            const alert = await this.alertController.create({
              header: 'Gracias!' + ' ' + usuarioData.nombre,
              message: 'Sus datos han sido enviados!',
              buttons: ['OK'],
            });
  
            await alert.present();
  
            this.usuarioForm.reset();
          },
          error: (error) => {
            console.error('Error al guardar los datos:', error);
          },
        });
    }
  }
}
